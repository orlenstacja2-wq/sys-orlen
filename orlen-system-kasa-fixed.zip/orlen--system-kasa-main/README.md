# ORLEN – System obsługi stacji paliw

Webowa aplikacja do ewidencjonowania i rozliczania tankowań dla stacji ORLEN przy Alei Armii Krajowej 46 w Rzeszowie. Wymaga skonfigurowanej Netlify Database. Przy pierwszym uruchomieniu administrator tworzy konto, a pracownicy logują się loginem i PIN-em. Przed rejestrowaniem tankowań pracownik musi otworzyć zmianę i wybrać kasę. Dokumenty generowane przez aplikację są potwierdzeniami niefiskalnymi — nie zastępują certyfikowanego systemu fiskalnego.

## Funkcje

- **Logowanie** loginem i PIN-em pracownika. Przy pierwszym uruchomieniu można skonfigurować konto administratora; jeśli ustawiono `SETUP_CODE`, konfiguracja wymaga tego kodu.
- **Dystrybutory 1–5**: symulowani klienci pojawiają się wyłącznie po włączeniu trybu szkoleniowego. Aplikacja nie jest połączona z fizycznymi sterownikami dystrybutorów.
- **Kasa**: dystrybutor → paliwo → litry → paragon/faktura (NIP, nabywca) → VITAY → gotówka/karta. Kwota liczy się automatycznie z cennika, a przy gotówce kasa pokazuje resztę.
- **ORLEN VITAY**: przed każdą płatnością na całym ekranie pojawia się pytanie TAK/NIE.
- **Paragon 57 mm** z logo, adresem, datą, dystrybutorem, paliwem, litrami, ceną, sumą, PTU, metodą płatności i informacją o VITAY. Każdy dokument z historii można wydrukować ponownie.
- **Cennik i historia tankowań** z sumą zmiany.

## Obsługa klawiaturą

| Klawisz        | Działanie                                         |
| -------------- | ------------------------------------------------- |
| `ENTER`        | zatwierdź / dalej                                 |
| `ESC`          | cofnij o krok                                     |
| Strzałki       | poruszanie się po opcjach                         |
| `1`–`5`        | szybki wybór dystrybutora lub paliwa              |
| `P` / `F`      | paragon / faktura                                 |
| `T` / `N`      | VITAY: tak / nie                                  |
| `G` / `K`      | gotówka / karta                                   |
| `ENTER` (puste pole gotówki) | klient płaci odliczoną kwotę        |
| `N` (po transakcji) | nowa transakcja bez wydruku                  |
| `F10`          | wyloguj                                           |

## Drukowanie

Paragon otwiera systemowe okno drukowania z formatem strony 57 mm × auto. W ustawieniach drukarki termicznej wybierz papier 57 mm i wyłącz marginesy oraz nagłówki i stopki przeglądarki.

## Ważne wymagania wdrożeniowe\n\n- Skonfiguruj Netlify Database i zastosuj migracje z `netlify/database/migrations`.\n- Ustaw `SETUP_CODE` w zmiennych środowiskowych, jeśli pierwsza konfiguracja administratora ma wymagać dodatkowego kodu.\n- Oficjalna weryfikacja VITAY, drukarka fiskalna, terminal płatniczy i sterownik dystrybutorów wymagają osobnych, autoryzowanych integracji.\n\n## Technologie

TanStack Start (React 19), Tailwind CSS 4, lucide-react, sonner. Hosting na Netlify.

## Uruchomienie lokalne

```bash
pnpm install
pnpm dev            # http://localhost:3000
# lub z emulacją Netlify:
netlify dev
```

## Uwagi

- Stan stacji (dystrybutory, historia) jest przechowywany w pamięci przeglądarki na czas działania karty. Po odświeżeniu strony zmiana zaczyna się od nowa.
- Kod dostępu jest sprawdzany w przeglądarce. Zabezpiecza stanowisko przed przypadkowym użyciem, ale nie zastępuje prawdziwego uwierzytelniania.
- Wydruk jest symulacją paragonu fiskalnego. Prawnie ważne paragony wystawia certyfikowana drukarka fiskalna.
